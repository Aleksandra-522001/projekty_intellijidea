package com.capgemini.wsb.fitnesstracker.training.internal;

import com.capgemini.wsb.fitnesstracker.training.api.Training;

public class TrainingMapper {
    public static Training toEntity(TrainingDto trainingDto) {
        //konwersja obiektu DTO na encję
        }
    public static TrainingDto toDto(Training training) {
        // Konwersja obiektu encji na obiekt DTO
        return null;
    }


}

