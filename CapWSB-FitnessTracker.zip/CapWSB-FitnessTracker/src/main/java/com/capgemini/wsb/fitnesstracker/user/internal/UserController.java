package com.capgemini.wsb.fitnesstracker.user.internal;

import com.capgemini.wsb.fitnesstracker.training.internal.TrainingDto;
import com.capgemini.wsb.fitnesstracker.training.internal.TrainingServiceImpl;
import com.capgemini.wsb.fitnesstracker.user.api.User;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/v1/users")
@RequiredArgsConstructor
class UserController {

    private final UserServiceImpl userService;

    private final UserMapper userMapper;

    @GetMapping
    public List<UserDto> getAllUsers() {
        return userService.findAllUsers()
                          .stream()
                          .map(userMapper::toDto)
                          .toList();
    }

    @PostMapping
    public void createUser() {
        return userService.createUser()
                .stream()
                .map(userMapper::toDto)
                .toList();
    }





    @GetMapping("/{id}")
    public UserDto getUserById(@PathVariable("id") Integer id)
        {
     userService.findUserById(id);
            return null;
        }



    @GetMapping("/id")
    public UserDto getUserById(@PathVariable Long id) {
        return userService.getUser(id)
                .map(userMapper::toDto)
                .get();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }




    @GetMapping("/search")
    public ResponseEntity<List<UserDto>> searchUsersByEmail(@RequestParam String email) {
        List<UserDto> foundUsers = userService.searchUsersByEmail(email);
        return ResponseEntity.ok(foundUsers);
    }





    @GetMapping("/search")
    public ResponseEntity<List<UserDto>> searchUsersByMinAge(@RequestParam int minAge) {
        List<UserDto> foundUsers = userService.searchUsersByMinAge(minAge);
        return ResponseEntity.ok(foundUsers);
    }





    @PutMapping("/{id}")
    public ResponseEntity<UserDto> updateUser(@PathVariable Long id, @RequestBody UserDto userDto) {
        UserDto updatedUser = userService.updateUser(id, userDto);
        if (updatedUser != null) {
            return ResponseEntity.ok(updatedUser);
        } else {
            return ResponseEntity.notFound().build();
        }
    }





}