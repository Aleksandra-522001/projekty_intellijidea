package com.capgemini.wsb.fitnesstracker.training.internal;

import com.capgemini.wsb.fitnesstracker.training.api.Training;
import com.capgemini.wsb.fitnesstracker.training.api.TrainingProvider;
import com.capgemini.wsb.fitnesstracker.user.api.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

// TODO: Provide Impl
@Service
public class TrainingServiceImpl implements TrainingProvider {
@Autowired
private TrainingRepository trainingRepository;

    //TODO: fix this bug
    @Override
    public Optional<User> getTraining(final Long trainingId) {
        throw new UnsupportedOperationException("Not finished yet");
    }

    @Override
    public List<Training> getAllTrainings() {
        // TODO: GetAllTraining from DB
        return List.of();
    }


    public void createTraining(TrainingDto trainingDto) {
        // Konwersja DTO na obiekt encji i zapis do bazy danych
        Training training = TrainingMapper.toEntity(trainingDto);
        trainingRepository.save(training);
    }

    public List<Training> getTrainingsForUser(Long userId) {
        return List.of();
    }

    public List<Training> getCompletedTrainingsAfterDate(LocalDate date) {
        return List.of();
    }

    public List<Training> getTrainingsByActivity(String activity) {
        return List.of();
    }

    public void updateTraining(Long id, TrainingDto trainingDto) {
    }
}
