package com.capgemini.wsb.mapper;

import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Optional;

public class PatientRepositoryImpl implements PatientRepository {
    @Override
    public Object save(Object o) {
        return null;
    }

    @Override
    public Optional findById(Object o) {
        return Optional.empty();
    }

    @Override
    public boolean existsById(Object o) {
        return false;
    }

    @Override
    public List<PatientEntity> findAll() {
        return List.of();
    }

    @Override
    public List<PatientEntity> findAll(Sort sort) {
        return List.of();
    }


    @Override
    public void flush() {

    }

    @Override
    public void deleteInBatch(Iterable iterable) {

    }

    @Override
    public void deleteAllInBatch() {

    }

    @Override
    public Object getOne(Object o) {
        return null;
    }

    @Override
    public List findAll(Example example, Sort sort) {
        return List.of();
    }

    @Override
    public List findAll(Example example) {
        return List.of();
    }

    @Override
    public Object saveAndFlush(Object o) {
        return null;
    }

    @Override
    public List saveAll(Iterable iterable) {
        return List.of();
    }

    @Override
    public Page<PatientEntity> findAll(Pageable pageable) {
        return null;
    }

    @Override
    public List<PatientEntity> findAllById(Iterable<Long> iterable) {
        return List.of();
    }

    @Override
    public long count() {
        return 0;
    }

    @Override
    public void deleteById(Object o) {

    }

    @Override
    public void delete(Object o) {

    }

    @Override
    public void deleteAll(Iterable iterable) {

    }

    @Override
    public void deleteById(Long aLong) {

    }

    @Override
    public void delete(PatientEntity patientEntity) {

    }

    @Override
    public void deleteAll() {

    }


    @Override
    public Optional findOne(Example example) {
        return Optional.empty();
    }

    @Override
    public Page findAll(Example example, Pageable pageable) {
        return null;
    }

    @Override
    public long count(Example example) {
        return 0;
    }

    @Override
    public boolean exists(Example example) {
        return false;
    }
}
