import com.capgemini.wsb.dto.PatientTO;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component

public class PatientMapper {


    private final ModelMapper modelMapper;

    @Autowired
    public PatientMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public PatientTO mapToPatientTO(PatientEntity patientEntity) {
        return modelMapper.map(patientEntity, PatientTO.class);
    }

    public PatientEntity mapToPatientEntity(PatientTO patientTO) {
        return modelMapper.map(patientTO, PatientEntity.class);
    }
}

public void main() {
}

public void main() {
}
