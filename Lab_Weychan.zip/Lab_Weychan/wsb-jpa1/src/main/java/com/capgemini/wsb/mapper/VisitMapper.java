package com.capgemini.wsb.mapper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class VisitMapper {

    private final ModelMapper modelMapper;

    public VisitMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public VisitTO convertToTO(VisitEntity visitEntity) {
        return modelMapper.map(visitEntity, VisitTO.class);
    }

    public VisitEntity convertToEntity(VisitTO visitTO) {
        return modelMapper.map(visitTO, VisitEntity.class);
    }
}
