package com.capgemini.wsb.fitnesstracker.training.internal;


import com.capgemini.wsb.fitnesstracker.training.api.Training;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Setter
@Getter
@RestController
@RequestMapping("/v1/trainings")
@RequiredArgsConstructor
public class TrainingController {

      private TrainingServiceImpl trainingService;
      //tworzenie nowego treningu
      @PostMapping
      public void createTraining(@RequestBody TrainingDto trainingDto){
          trainingService.createTraining(trainingDto);
      }


//wyszukiwanie wszystskich treningów
    @GetMapping
    public List<Training> getAllTraining(){
        return trainingService.getAllTrainings();
    }


    //wyszukiwanie treningów dla określonego użytkownika
    @GetMapping("/user/{userId}")
    public List<Training> getTrainingsForUser(@PathVariable Long userId) {
        return trainingService.getTrainingsForUser(userId);
    }

    // Wyszukiwanie wszystkich treningów zakończonych po konkretnej zdefiniowanej dacie
    @GetMapping("/completed")
    public List<Training> getCompletedTrainingsAfterDate(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return trainingService.getCompletedTrainingsAfterDate(date);
    }
    //wyszukiwanie wszystkich treningów dla konkretnej aktywności
    @GetMapping("/activity/{activity}")
    public List<Training> getTrainingsByActivity(@PathVariable String activity) {
        return trainingService.getTrainingsByActivity(activity);
    }

    //aktualizacja treningu
    @PutMapping("/{id}")
    public void updateTraining(@PathVariable Long id, @RequestBody TrainingDto trainingDto) {
        trainingService.updateTraining(id, trainingDto);
    }


}
