insert into address (id, address_line1, address_line2, city, postal_code)
            values (1, 'xx', 'yy', 'city', '62-030');

---DOCTORS---
insert into doctor (id, first_name, last_name, telephone_number, email, doctor_number, specialization)
    values (1, 'Eryk', 'Histeryk', '333-111', 'eryk@dziubek.pl', 1, 'ORTHOPAEDIST');
insert into doctor (id, first_name, last_name, telephone_number, email, doctor_number, specialization)
    values (2, 'Olka', 'Awantura', '000-222', 'olka@dziubek.pl', 20, 'LARYNGOLOGIST');
insert into doctor (id, first_name, last_name, telephone_number, email, doctor_number, specialization)
    values (3, 'Weronika', 'Kocica', '999-999', 'wercia@dziubek.pl', 30, 'PSYCHOLOGIST');

---PATIENTS---
insert into patient (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth)
    values (1, 'Nikola', 'Magier', '010-020', 'nikola@dziubek.pl', 90, TIMESTAMP '2001-09-21 00:00:00');
insert into patient (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth)
    values (2, 'Jacek', 'Dudziński', '890-980', 'jacek@dziubek.pl', 80, TIMESTAMP '1900-03-03 00:00:00');
insert into patient (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth)
    values (3, 'Ewa', 'Skuza', '722-999', ewa@dziubek.pl, 96, TIMESTAMP '1960-10-20 00:00:00');
insert into patient (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth)
    values (4, 'Adam', 'Kowalski', '123-456', 'adam@example.com', 'AK123', TIMESTAMP '1990-01-01 00:00:00');
insert into patient (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth)
    values (5, 'Ewa', 'Nowak', '789-012', 'ewa@example.com', 'EN456', TIMESTAMP '1985-05-05 00:00:00');
insert into patient (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth)
    values (6, 'Jan', 'Wiśniewski', '321-654', 'jan@example.com', 'JW789', TIMESTAMP '1978-10-10 00:00:00');


---VISITS---
insert into visit (id, description, time, doctor_id, patient_id)
    values (1, 'Visit 1', TIMESTAMP '2024-05-10 10:00:00', 1, 1);
insert into visit (id, description, time, doctor_id, patient_id)
    values (2, 'Visit 2', TIMESTAMP '2024-10-10 13:40:00', 2, 1);

insert into visit (id, description, time, doctor_id, patient_id)
    values (3, 'Visit 3', TIMESTAMP '2024-06-01 14:00:00', 3, 2);
insert into visit (id, description, time, doctor_id, patient_id)
    values (4, 'Visit 4', TIMESTAMP '2024-09-20 15:30:00', 1, 3);
insert into visit (id, description, time, doctor_id, patient_id)
    values (5, 'Visit 5', TIMESTAMP '2024-08-09 17:10:00', 2, 2);
insert into visit (id, description, time, doctor_id, patient_id)
    values (6, 'Visit 6', TIMESTAMP '2024-01-03 08:45:00', 1, 2);
insert into visit (id, description, time, doctor_id, patient_id)
    values (7, 'Visit 7', TIMESTAMP '2024-11-13 18:20:00', 3, 3);
insert into visit (id, description, time, doctor_id, patient_id)
    values (8, 'Visit 8', TIMESTAMP '2024-04-24 12:00:00', 2, 1);
insert into visit (id, description, time, doctor_id, patient_id)
    values (9, 'Visit 9', TIMESTAMP '2024-03-15 16:00:00', 2, 1);
insert into visit (id, description, time, doctor_id, patient_id)
    values (10, 'Visit 9', TIMESTAMP '2024-07-07 07:00:00', 3, 1);

insert into visit (id, description, time, doctor_id, patient_id)
    values (11, 'Visit 11', TIMESTAMP '2024-05-10 10:00:00', 1, 4);
insert into visit (id, description, time, doctor_id, patient_id)
    values (12, 'Visit 12', TIMESTAMP '2024-05-15 14:30:00', 2, 4);
insert into visit (id, description, time, doctor_id, patient_id)
    values (13, 'Visit 13', TIMESTAMP '2024-06-01 08:00:00', 3, 5);
insert into visit (id, description, time, doctor_id, patient_id)
    values (14, 'Visit 14', TIMESTAMP '2024-06-15 16:30:00', 1, 5);
insert into visit (id, description, time, doctor_id, patient_id)
    values (15, 'Visit 15', TIMESTAMP '2024-07-01 12:00:00', 2, 6);
insert into visit (id, description, time, doctor_id, patient_id)
    values (16, 'Visit 16', TIMESTAMP '2024-07-15 10:30:00', 3, 6);



---MEDICAL TREATMENTS---
insert into medical_treatment (id, description, type, visit_id)
    values (1, 'headache', 'RTG', 1);
insert into medical_treatment (id, description, type, visit_id)
    values (2, 'cold', 'USG', 1);
insert into medical_treatment (id, description, type, visit_id)
    values (3, 'otitis', 'RTG', 10);

---OTHER DOCS---
INSERT INTO doctor (first_name, last_name, telephone_number, email, doctor_number, specialization)
VALUES
    ('Anna', 'Pigwa', '000-232', 'ania@wp.pl', 1, 'SURGEON'),
    ('Maciej', 'Ptak', '434-222', 'maciej@wp.pl', 3, 'SURGEON'),
    ('Wojtek', 'Winny', '999-998', 'wojtek@wp.pl', 5, 'SURGEON'),
    ('Celina', 'Owoc', '666-454', 'celina@wp.pl', 7, 'SURGEON'),