package com.capgemini.wsb.fitnesstracker.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * Aspekt odpowiedzialny za logowanie wywołań metod serwisów.
 */
@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);
    /**
     * Loguje informacje przed wywołaniem metody serwisu.
     * @param joinPoint Obiekt JoinPoint reprezentujący punkt złączenia w trakcie wykonania programu.
     */
    @Before("execution(* com.capgemini.wsb.fitnesstracker.*.*(..)) && @target(org.springframework.stereotype.Service)")
    public void logBeforeMethodCall(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getName();
        Object[] args = joinPoint.getArgs();
        StringBuilder argsString = new StringBuilder();
        for (Object arg : args) {
            if (argsString.length() > 0) {
                argsString.append(", ");
            }
            argsString.append(arg != null ? arg.toString() : "null");
        }
        logger.info("Before method call: {} {}({})", className, methodName, argsString);
    }
    /**
     * Loguje informacje po wywołaniu metody serwisu.
     * @param joinPoint Obiekt JoinPoint reprezentujący punkt złączenia w trakcie wykonania programu.
     * @param result Zwrócona wartość z metody serwisu.
     */
    @AfterReturning(pointcut = "execution(* com.capgemini.wsb.fitnesstracker.*.*(..)) && @target(org.springframework.stereotype.Service)", returning = "result")
    private void logAfterMethodCall(JoinPoint joinPoint, Object result) {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getName();
        logger.info("After method call: {} {}(), result: {}", className, methodName, result != null ? result.toString() : "null");
    }
}

