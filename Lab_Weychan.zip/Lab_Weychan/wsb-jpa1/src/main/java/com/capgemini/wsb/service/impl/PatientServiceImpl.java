package com.capgemini.wsb.service.impl;
import com.capgemini.wsb.dto.PatientTO;
import com.capgemini.wsb.mapper.PatientMapper;
import com.capgemini.wsb.mapper.PatientRepository;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;


@Service
@Transactional
public class PatientServiceImpl implements PatientService {

    private PatientRepository patientRepository;
    private final PatientMapper modelMapper = null;

    @Autowired
    public PatientMapper PatientServiceImpl;< PatientRepository, PatientMapper> {
        this.patientRepository = patientRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public PatientTO savePatient(PatientTO patientTO) {
        PatientEntity patientEntity = modelMapper.map(patientTO, PatientEntity.class);
        PatientEntity savedEntity = (PatientEntity) patientRepository.save(patientEntity);
        return modelMapper.map(savedEntity, PatientTO.class);
    }

    @Override
    public PatientTO updatePatient(PatientTO patientTO) {
    }

    @Override
    public com.capgemini.wsb.service.impl.PatientTO savePatient(com.capgemini.wsb.service.impl.PatientTO patient) {
        return null;
    }

    @Override
    public com.capgemini.wsb.service.impl.PatientTO updatePatient(com.capgemini.wsb.service.impl.PatientTO patient) {
        return null;
    }

    @Override
    public void deletePatient(Long patientId) {

    }

    @Override
    public com.capgemini.wsb.service.impl.PatientTO getPatientById(Long patientId) {

        return null;
    }

    @Override
    public List<com.capgemini.wsb.service.impl.PatientTO> getAllPatients() {
        return List.of();
    }

    @Override
    public List<VisitEntity> findVisitsByPatientId(Long patientId) {
        return List.of();
    }

}
