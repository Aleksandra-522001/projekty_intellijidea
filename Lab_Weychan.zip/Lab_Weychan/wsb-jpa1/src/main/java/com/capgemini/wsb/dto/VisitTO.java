package com.capgemini.wsb.dto;
import java.io.Serializable;
import java.time.LocalDate;

public class VisitTO implements Serializable {

    private Long id;
    private LocalDate time;
    private PatientTO.DoctorTO doctor;
    private PatientTO patient;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getTime() {
        return time;
    }

    public void setVisitDate(LocalDate time) {
        this.time = this.time;
    }

    public PatientTO.DoctorTO getDoctor() {
        return doctor;
    }

    public void setDoctor(PatientTO.DoctorTO doctor) {
        this.doctor = doctor;
    }

    public PatientTO getPatient() {
        return patient;
    }

    public void setPatient(PatientTO patient) {
        this.patient = patient;
    }
}
