package com.capgemini.wsb;

public class UserServiceTest {
}
