package com.capgemini.wsb.persistence.enums;

public enum Specialization {

	ORTHOPAEDIST,
	GP,
	LARYNGOLOGIST,
	PSYCHOLOGIST

}
