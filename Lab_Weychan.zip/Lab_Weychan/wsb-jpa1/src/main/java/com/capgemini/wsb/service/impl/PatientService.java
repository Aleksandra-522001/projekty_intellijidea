package com.capgemini.wsb.service.impl;


import com.capgemini.wsb.mapper.PatientMapper;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;



@Service
public interface PatientService {


    PatientMapper patientMapper = null;


    PatientTO savePatient(PatientTO patient);

    PatientTO updatePatient(PatientTO patient);

    void deletePatient(Long patientId);

    PatientTO getPatientById(Long patientId);

    List<PatientTO> getAllPatients();

    List<VisitEntity> findVisitsByPatientId(Long patientId);
}
