package com.capgemini.wsb.mapper;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
    public class PatientRepository<PatientEntity> implements JpaRepository<PatientEntity, Long> {
    @Override
    public List<PatientEntity> findAll() {
        return List.of();
    }

    @Override
    public List<PatientEntity> findAll(Sort sort) {
        return List.of();
    }

    @Override
    public Page<PatientEntity> findAll(Pageable pageable) {
        return null;
    }

    @Override
    public List<PatientEntity> findAllById(Iterable<Long> iterable) {
        return List.of();
    }

    @Override
    public long count() {
        return 0;
    }

    @Override
    public void deleteById(Long aLong) {

    }

    @Override
    public void delete(PatientEntity patientEntity) {

    }

    @Override
    public void deleteAll(Iterable<? extends PatientEntity> iterable) {

    }

    @Override
    public void deleteAll() {

    }

    @Override
    public <S extends PatientEntity> S save(S s) {
        return null;
    }

    @Override
    public <S extends PatientEntity> List<S> saveAll(Iterable<S> iterable) {
        return List.of();
    }

    @Override
    public Optional<PatientEntity> findById(Long aLong) {
        return Optional.empty();
    }

    @Override
    public boolean existsById(Long aLong) {
        return false;
    }

    @Override
    public void flush() {

    }

    @Override
    public <S extends PatientEntity> S saveAndFlush(S s) {
        return null;
    }

    @Override
    public void deleteInBatch(Iterable<PatientEntity> iterable) {

    }

    @Override
    public void deleteAllInBatch() {

    }

    @Override
    public PatientEntity getOne(Long aLong) {
        return null;
    }

    @Override
    public <S extends PatientEntity> Optional<S> findOne(Example<S> example) {
        return Optional.empty();
    }

    @Override
    public <S extends PatientEntity> List<S> findAll(Example<S> example) {
        return List.of();
    }

    @Override
    public <S extends PatientEntity> List<S> findAll(Example<S> example, Sort sort) {
        return List.of();
    }

    @Override
    public <S extends PatientEntity> Page<S> findAll(Example<S> example, Pageable pageable) {
        return null;
    }

    @Override
    public <S extends PatientEntity> long count(Example<S> example) {
        return 0;
    }

    @Override
    public <S extends PatientEntity> boolean exists(Example<S> example) {
        return false;
    }

    public List<com.capgemini.wsb.persistence.entity.PatientEntity> findByLastName(String kowalski) {
        return List.of();
    }
}
