package com.capgemini.wsb.service.impl;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.List;
import com.capgemini.wsb.mapper.PatientRepository;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
public class PatientRepositoryTest {

    @Autowired
    private PatientRepository patientRepository;

    @Test
    public void testFindPatientsByLastName() {
        // Wczytaj dane testowe
        PatientEntity patient = new PatientEntity();
        patient.setFirstName("Jan");
        patient.setLastName("Kowalski");
        patientRepository.save(patient);

        // Wykonaj zapytanie
        List<PatientEntity> patients = patientRepository.findByLastName("Kowalski");

        // Sprawdź czy wynik zawiera oczekiwaną liczbę pacjentów
        equals(1, patients.size());
        // Sprawdź inne aspekty wyniku, np. imiona pacjentów, etc.
    }

    private void equals(int i, int size) {
    }
}
