package com.capgemini.wsb.persistence.dao;

import com.capgemini.wsb.persistence.dao.impl.AbstractDao;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.springframework.stereotype.Repository;

@Repository
public class PatientDaoImpl  extends AbstractDao<PatientEntity, Long> implements PatientDao
{

}
