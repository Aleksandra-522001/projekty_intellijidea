package com.capgemini.wsb.persistence.dao;

public interface PatientDao {


}
