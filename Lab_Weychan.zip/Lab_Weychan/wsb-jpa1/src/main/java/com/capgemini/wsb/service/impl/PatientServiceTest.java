package com.capgemini.wsb.service.impl;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import com.capgemini.wsb.persistence.entity.VisitEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

public class PatientServiceTest {

    @InjectMocks
    private PatientServiceImpl patientService;

    @Mock
    private PatientRepository patientRepository;

    @Mock
    private VisitRepository visitRepository;

    @Mock
    private ModelMapper modelMapper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testDeletePatientCascadeVisits() {
        // Given
        PatientEntity patientEntity = new PatientEntity();
        patientEntity.setId(1L);
        patientEntity.setFirstName("Nikola");
        patientEntity.setLastName("Magier");

        VisitEntity visit1 = new VisitEntity();
        visit1.setId(1L);
        visit1.setPatient(patientEntity);

        VisitEntity visit2 = new VisitEntity();
        visit2.setId(2L);
        visit2.setPatient(patientEntity);

        patientEntity.setVisits(Arrays.asList(visit1, visit2));

        when(patientRepository.findById(anyLong())).thenReturn(Optional.of(patientEntity));

        // When
        patientService.deletePatient(1L);

        // Then
        verify(visitRepository, times(1)).deleteAll(patientEntity.getVisits());
        verify(patientRepository, times(1)).deleteById(1L);
        // Ensure doctors are not deleted
        verify(patientRepository, times(0)).deleteAll();
    }

    @Test
    public void testGetPatientById() {

    }

    private Object anyLong() {
    }
}

//test 2

@SpringBootTest
public class PatientServiceTest {

    @Mock
    private VisitRepository visitRepository;

    @InjectMocks
    private PatientService patientService;

    @Test
    public void testFindVisitsByPatientId() {
        // Ustawienie danych testowych
        Long patientId = 1L;
        VisitEntity visit1 = new VisitEntity();
        // Ustawienie szczegółów wizyty
        VisitEntity visit2 = new VisitEntity();
        // Ustawienie szczegółów wizyty
        when(visitRepository.findByPatientId(patientId)).thenReturn(Arrays.asList(visit1, visit2));

        // Wywołanie metody serwisu
        List<VisitEntity> visits = patientService.findVisitsByPatientId(patientId);

        // Sprawdzenie czy wynik zawiera oczekiwaną liczbę wizyt
        assertEquals(2, visits.size());
        // Sprawdzenie innych aspektów wyniku, np. szczegóły wizyt, etc.
    }

    private org.mockito.stubbing.OngoingStubbing<List<VisitEntity>> when(Object byPatientId) {
    }
}

