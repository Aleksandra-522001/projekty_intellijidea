package com.capgemini.wsb.service.impl;

import com.capgemini.wsb.dto.PatientTO;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;
import com.capgemini.wsb.dto.PatientTO;
import com.capgemini.wsb.persistence.entity.PatientEntity;

@Component
public class PatientMapper {

    private final ModelMapper modelMapper;

    public PatientMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public PatientTO mapToTO(PatientEntity patientEntity) {
        return modelMapper.map(patientEntity, PatientTO.class);
    }

    public PatientEntity mapToEntity(PatientTO patientTO) {
        return modelMapper.map(patientTO, PatientEntity.class);
    }
}
