package com.capgemini.wsb.service.impl;

public class VisitRepository {
    public Object findByPatientId(Long patientId) {
        return null;
    }
}
