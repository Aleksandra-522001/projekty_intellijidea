package com.capgemini.wsb.persistence.enums;

public enum TreatmentType {

	USG,
	EKG,
	RTG
}
