@NonNullByDefault
package com.capgemini.wsb.fitnesstracker.mail.internal;

import org.eclipse.jdt.annotation.NonNullByDefault;